module.exports = {
    release: "28/03/2024",
    bugs: [
        "---",
    ],
    features: [
        "---",
    ],
};

 