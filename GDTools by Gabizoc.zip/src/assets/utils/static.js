module.exports.defaultPFP = 'https://cdn.discordapp.com/embed/avatars/0.png';

module.exports.DummyUser = {
    bot: false,
    id: '00000000000',
    tag: "Utilisateur Inconnu#0000",
    name: "Utilisateur Inconnu",
    username: "Utilisateur Inconnu",
    hexAccentColor: "#FFFFFF",
    avatarURL: () => 'https://cdn.discordapp.com/embed/avatars/0.png'
}