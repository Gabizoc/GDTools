const Discord = require('discord.js');
const chalk = require('chalk');

module.exports = (client, node) => {
    console.log(chalk.blue(chalk.bold(`Bot Systéme`)), (chalk.white(`>>`)), chalk.red(``), chalk.green(`connecter !`))
};